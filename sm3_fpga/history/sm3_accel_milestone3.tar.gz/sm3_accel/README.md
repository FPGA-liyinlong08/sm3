# SM3 FPGA Multi-Core Accelerator

Current verified baseline for many independent short/mid-size messages.

## Toolchain

- Verilator 5.048
- cocotb 2.1.0
- Python 3.13

The sandbox uses a locally extracted Verilator and a local Python venv; tool binaries are not included in the source archive.

## RTL implemented

### `rtl/core/sm3_core.sv`

- iterative SM3 compression core
- 1 round/cycle
- 16 x 32-bit W sliding window
- input/output ready-valid
- output backpressure holding

### `rtl/sched/sm3_core_pool.sv`

- parameterized 8/16-core single-block baseline
- dynamic first-free-core dispatch
- centralized completion arbitration

### `rtl/context/sm3_context_store.sv`

- RAM-oriented Context/Block storage
- one pending 512-bit block per context
- one 256-bit chaining state per context
- independent 1W block port and 1W hash-state port
- synchronous dispatch read port
- `ram_style="block"` hints for FPGA synthesis

### `rtl/context/sm3_multiblock_engine.sv`

- parameterized `CORE_NUM` and `CTX_NUM`
- one inflight block per message/context invariant
- one additional pending block per context (one-block prefetch window)
- synchronous RAM-read dispatch pipeline
- explicit core reservation between scheduler select and core launch
- context hash writeback for non-final blocks
- context release + digest result for final blocks
- out-of-order completion by Message ID

The current block-stream interface assumes an upstream descriptor/context allocator supplies `ctx_id`. This intentionally avoids a large Message-ID CAM in the datapath.

## Verification

### Golden model

`model/sm3_ref.py` implements padding, expansion, compression, and full hash.

### Multi-block stress test

`tb/test_sm3_multiblock.py` covers:

- message sizes 0..4096 bytes
- explicit 55/56, 63/64, 119/120 and other boundary sizes
- random message payloads
- multiple concurrent Message Contexts
- randomized source gaps
- randomized result backpressure
- out-of-order completion
- context reuse
- direct dispatch/commit pairing checker
- assertion that a context is never dispatched twice while inflight
- exact final digest comparison against Python SM3

## Verified regression results

### 8 cores / 32 contexts

- 250 messages
- 2957 compression blocks
- 26134 cycles in the randomized run
- all 8 cores reached occupied state
- all 32 contexts reached active/pending state
- 0.113148 block/cycle
- average core occupied/reserved utilization: 93.37%
- PASS

### 16 cores / 64 contexts

- 160 messages
- 2035 compression blocks
- 10393 cycles in the randomized run
- all 16 cores reached occupied state
- all 64 contexts reached active/pending state
- 0.195805 block/cycle
- average core occupied/reserved utilization: 80.81%
- PASS

The 16-core result shows that simply doubling cores does not automatically double end-to-end throughput for a mixed short-message workload. Context turnaround, message start/finalization, dispatch serialization, and short-message churn become visible. This is the next optimization target.

## Run

```bash
source scripts/env.sh

# single core
make SIM=verilator

# single-block core pool
make -f Makefile.pool CORE_NUM=8 SIM=verilator

# multi-block context engine
NMSG=250 make -f Makefile.multi CORE_NUM=8 CTX_NUM=32 SIM=verilator
NMSG=160 make -f Makefile.multi CORE_NUM=16 CTX_NUM=64 SIM=verilator
```

Or:

```bash
CORE_NUM=8 CTX_NUM=32 NMSG=250 scripts/run_multiblock_cocotb.sh
```

## Next optimization

Do not add more cores yet. First improve short-message efficiency:

1. add a single-block fast path (`first && last`) that bypasses Context RAM;
2. share the same core pool between fast single-block work and multi-block contexts;
3. add weighted/round-robin arbitration so fast traffic cannot starve multi-block messages;
4. then compare against Sticky-Core / quantum=4 for long-ish messages;
5. only after that integrate the 128-bit payload prefetch/front-end.
