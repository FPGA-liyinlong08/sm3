# SM3 FPGA Multi-Core Accelerator

Current verified baseline for the short-message architecture.

## Toolchain

- Verilator 5.048
- cocotb 2.1.0
- Python 3.13

The tools are used locally from `.tools/` / `.venv/` in the working sandbox; they are not included in the source archive.

## RTL implemented

- `rtl/core/sm3_core.sv`
  - iterative SM3 compression core
  - 1 round/cycle
  - 16 x 32-bit message expansion sliding window
  - ready/valid input and output
  - output backpressure holding
- `rtl/sched/sm3_core_pool.sv`
  - parameterized `CORE_NUM`
  - dynamic first-free-core dispatch
  - centralized completion arbitration
  - fixed SM3 IV for single-block messages
  - debug occupied-core bitmap

## Verification implemented

- `model/sm3_ref.py`: Python SM3 golden model
- `tb/test_sm3_core.py`: single-core cocotb regression
- `tb/test_sm3_core_pool.py`: multi-core randomized stress regression

### Verified results

Single core:

- known SM3 vectors: PASS
- 100 random compression blocks: PASS
- random messages 0..4096 bytes: PASS
- output backpressure stability: PASS

8-core pool:

- 1000 randomized 0..55-byte messages: PASS
- randomized source gaps: enabled
- randomized result backpressure: enabled
- maximum occupied cores: 8/8
- 8360 cycles, 0.119617 message/cycle in this randomized run

16-core pool:

- 200 randomized 0..55-byte messages: PASS
- randomized source gaps/backpressure: enabled
- maximum occupied cores: 16/16
- 877 cycles, 0.228050 message/cycle in this randomized run

## Run examples

With the local Verilator/cocotb environment activated:

```bash
make SIM=verilator
make -f Makefile.pool CORE_NUM=8 SIM=verilator
NMSG=200 make -f Makefile.pool CORE_NUM=16 SIM=verilator
```

## Next milestone

Add multi-block message support:

1. Message Context RAM
2. one-inflight-block-per-message invariant
3. context writeback / next-block ready path
4. randomized 0..4096-byte concurrent message regression
5. then add Sticky Core / block quantum optimization
