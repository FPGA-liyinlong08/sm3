// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtb_sm3_core.h for the primary calling header

#ifndef VERILATED_VTB_SM3_CORE___024ROOT_H_
#define VERILATED_VTB_SM3_CORE___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vtb_sm3_core__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtb_sm3_core___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ tb_sm3_core__DOT__clk;
        CData/*0:0*/ tb_sm3_core__DOT__rst_n;
        CData/*0:0*/ tb_sm3_core__DOT__in_valid;
        CData/*0:0*/ tb_sm3_core__DOT__in_ready;
        CData/*0:0*/ tb_sm3_core__DOT__block_last_in;
        CData/*0:0*/ tb_sm3_core__DOT__out_valid;
        CData/*0:0*/ tb_sm3_core__DOT__out_ready;
        CData/*0:0*/ tb_sm3_core__DOT__block_last_out;
        CData/*0:0*/ tb_sm3_core__DOT__stable_last;
        CData/*0:0*/ tb_sm3_core__DOT__dut__DOT__busy;
        CData/*5:0*/ tb_sm3_core__DOT__dut__DOT__round_idx;
        CData/*0:0*/ tb_sm3_core__DOT__dut__DOT__last_q;
        CData/*5:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j;
        CData/*5:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__tb_sm3_core__DOT__rst_n__0;
        CData/*0:0*/ __VactContinue;
        VlWide<16>/*511:0*/ tb_sm3_core__DOT__block_data;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__hash_in;
        IData/*31:0*/ tb_sm3_core__DOT__msg_id_in;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__hash_out;
        IData/*31:0*/ tb_sm3_core__DOT__msg_id_out;
        IData/*31:0*/ tb_sm3_core__DOT__rc;
        IData/*31:0*/ tb_sm3_core__DOT__msg_id_i;
        IData/*31:0*/ tb_sm3_core__DOT__last_i;
        IData/*31:0*/ tb_sm3_core__DOT__wait_cycles;
        VlWide<16>/*511:0*/ tb_sm3_core__DOT__vec_block;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__vec_state;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__vec_expected;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__stable_hash;
        IData/*31:0*/ tb_sm3_core__DOT__stable_id;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__a;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__b;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__c;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__d;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__e;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__f;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__g;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__h;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__dut__DOT__hash_base;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__msg_id_q;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wnext;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__an;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__bn;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__cn;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__dn;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__en;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__fn;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__gn;
        IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__hn;
        VlWide<8>/*255:0*/ tb_sm3_core__DOT__dut__DOT__round_state_next;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x;
    };
    struct {
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout;
        IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x;
        IData/*31:0*/ __VactIterCount;
        VlUnpacked<IData/*31:0*/, 16> tb_sm3_core__DOT__dut__DOT__w;
    };
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_h47e1613d__0;
    VlTriggerScheduler __VtrigSched_h47e160fc__0;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<4> __VactTriggered;
    VlTriggerVec<4> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vtb_sm3_core__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vtb_sm3_core___024root(Vtb_sm3_core__Syms* symsp, const char* v__name);
    ~Vtb_sm3_core___024root();
    VL_UNCOPYABLE(Vtb_sm3_core___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
