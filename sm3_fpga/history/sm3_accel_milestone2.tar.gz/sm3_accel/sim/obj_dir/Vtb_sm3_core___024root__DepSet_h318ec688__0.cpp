// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_sm3_core.h for the primary calling header

#include "Vtb_sm3_core__pch.h"
#include "Vtb_sm3_core___024root.h"

VlCoroutine Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__0(Vtb_sm3_core___024root* vlSelf);
VlCoroutine Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__1(Vtb_sm3_core___024root* vlSelf);

void Vtb_sm3_core___024root___eval_initial(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_initial\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0 
        = vlSelfRef.tb_sm3_core__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__rst_n__0 
        = vlSelfRef.tb_sm3_core__DOT__rst_n;
}

VL_INLINE_OPT VlCoroutine Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__1(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__1\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (1U) {
        co_await vlSelfRef.__VdlySched.delay(0x7d0ULL, 
                                             nullptr, 
                                             "tb/tb_sm3_core.sv", 
                                             5);
        vlSelfRef.tb_sm3_core__DOT__clk = (1U & (~ (IData)(vlSelfRef.tb_sm3_core__DOT__clk)));
    }
}

void Vtb_sm3_core___024root___eval_act(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Vtb_sm3_core___024root___nba_sequent__TOP__0(Vtb_sm3_core___024root* vlSelf);

void Vtb_sm3_core___024root___eval_nba(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb_sm3_core___024root___nba_sequent__TOP__0(vlSelf);
    }
}

extern const VlWide<8>/*255:0*/ Vtb_sm3_core__ConstPool__CONST_h9e67c271_0;

VL_INLINE_OPT void Vtb_sm3_core___024root___nba_sequent__TOP__0(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___nba_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wj;
    tb_sm3_core__DOT__dut__DOT__wj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wj4;
    tb_sm3_core__DOT__dut__DOT__wj4 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wpj;
    tb_sm3_core__DOT__dut__DOT__wpj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tj;
    tb_sm3_core__DOT__dut__DOT__tj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tj_rot;
    tb_sm3_core__DOT__dut__DOT__tj_rot = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__a12;
    tb_sm3_core__DOT__dut__DOT__a12 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__ss1;
    tb_sm3_core__DOT__dut__DOT__ss1 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__ss2;
    tb_sm3_core__DOT__dut__DOT__ss2 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tt1;
    tb_sm3_core__DOT__dut__DOT__tt1 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tt2;
    tb_sm3_core__DOT__dut__DOT__tt2 = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x = 0;
    CData/*0:0*/ __Vdly__tb_sm3_core__DOT__dut__DOT__busy;
    __Vdly__tb_sm3_core__DOT__dut__DOT__busy = 0;
    CData/*5:0*/ __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx;
    __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v0;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v0 = 0;
    CData/*0:0*/ __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v0;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v0 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v1;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v1 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v2;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v2 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v3;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v3 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v4;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v4 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v5;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v5 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v6;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v6 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v7;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v7 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v8;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v8 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v9;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v9 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v10;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v10 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v11;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v11 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v12;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v12 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v13;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v13 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v14;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v14 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v15;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v15 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v16;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v16 = 0;
    CData/*0:0*/ __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v16;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v16 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v17;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v17 = 0;
    CData/*0:0*/ __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v17;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v17 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v18;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v18 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v19;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v19 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v20;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v20 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v21;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v21 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v22;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v22 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v23;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v23 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v24;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v24 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v25;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v25 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v26;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v26 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v27;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v27 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v28;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v28 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v29;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v29 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v30;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v30 = 0;
    IData/*31:0*/ __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v31;
    __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v31 = 0;
    CData/*0:0*/ __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v32;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v32 = 0;
    // Body
    __Vdly__tb_sm3_core__DOT__dut__DOT__busy = vlSelfRef.tb_sm3_core__DOT__dut__DOT__busy;
    __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v0 = 0U;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v16 = 0U;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v17 = 0U;
    __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v32 = 0U;
    if (vlSelfRef.tb_sm3_core__DOT__rst_n) {
        if (((IData)(vlSelfRef.tb_sm3_core__DOT__out_valid) 
             & (IData)(vlSelfRef.tb_sm3_core__DOT__out_ready))) {
            vlSelfRef.tb_sm3_core__DOT__out_valid = 0U;
        }
        if (((IData)(vlSelfRef.tb_sm3_core__DOT__in_valid) 
             & (IData)(vlSelfRef.tb_sm3_core__DOT__in_ready))) {
            __Vdly__tb_sm3_core__DOT__dut__DOT__busy = 1U;
            __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx = 0U;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__a 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[7U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__b 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[6U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__c 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[5U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__d 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[4U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__e 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[3U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__f 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[2U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__g 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[1U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__h 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[0U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v0 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xfU];
            __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v0 = 1U;
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v1 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xeU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v2 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xdU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v3 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xcU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v4 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xbU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v5 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0xaU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v6 
                = vlSelfRef.tb_sm3_core__DOT__block_data[9U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v7 
                = vlSelfRef.tb_sm3_core__DOT__block_data[8U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v8 
                = vlSelfRef.tb_sm3_core__DOT__block_data[7U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v9 
                = vlSelfRef.tb_sm3_core__DOT__block_data[6U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v10 
                = vlSelfRef.tb_sm3_core__DOT__block_data[5U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v11 
                = vlSelfRef.tb_sm3_core__DOT__block_data[4U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v12 
                = vlSelfRef.tb_sm3_core__DOT__block_data[3U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v13 
                = vlSelfRef.tb_sm3_core__DOT__block_data[2U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v14 
                = vlSelfRef.tb_sm3_core__DOT__block_data[1U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v15 
                = vlSelfRef.tb_sm3_core__DOT__block_data[0U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__msg_id_q 
                = vlSelfRef.tb_sm3_core__DOT__msg_id_in;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__last_q 
                = vlSelfRef.tb_sm3_core__DOT__block_last_in;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[0U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[0U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[1U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[1U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[2U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[2U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[3U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[3U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[4U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[4U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[5U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[5U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[6U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[6U];
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[7U] 
                = vlSelfRef.tb_sm3_core__DOT__hash_in[7U];
        } else if (vlSelfRef.tb_sm3_core__DOT__dut__DOT__busy) {
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__a 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__an;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__b 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__c 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__cn;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__d 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__dn;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__e 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__en;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__f 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__g 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__gn;
            vlSelfRef.tb_sm3_core__DOT__dut__DOT__h 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__hn;
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v16 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [1U];
            __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v16 = 1U;
            if ((0x3fU == (IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx))) {
                __Vdly__tb_sm3_core__DOT__dut__DOT__busy = 0U;
                __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx = 0U;
                vlSelfRef.tb_sm3_core__DOT__out_valid = 1U;
                vlSelfRef.tb_sm3_core__DOT__hash_out[0U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[0U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[0U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[1U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[1U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[1U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[2U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[2U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[2U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[3U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[3U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[3U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[4U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[4U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[4U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[5U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[5U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[5U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[6U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[6U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[6U]);
                vlSelfRef.tb_sm3_core__DOT__hash_out[7U] 
                    = (vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[7U] 
                       ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[7U]);
                vlSelfRef.tb_sm3_core__DOT__msg_id_out 
                    = vlSelfRef.tb_sm3_core__DOT__dut__DOT__msg_id_q;
                vlSelfRef.tb_sm3_core__DOT__block_last_out 
                    = vlSelfRef.tb_sm3_core__DOT__dut__DOT__last_q;
            } else {
                __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx 
                    = (0x3fU & ((IData)(1U) + (IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx)));
            }
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v17 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [2U];
            __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v17 = 1U;
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v18 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [3U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v19 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [4U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v20 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [5U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v21 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [6U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v22 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [7U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v23 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [8U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v24 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [9U];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v25 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xaU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v26 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xbU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v27 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xcU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v28 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xdU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v29 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xeU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v30 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                [0xfU];
            __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v31 
                = vlSelfRef.tb_sm3_core__DOT__dut__DOT__wnext;
        }
    } else {
        vlSelfRef.tb_sm3_core__DOT__out_valid = 0U;
        __Vdly__tb_sm3_core__DOT__dut__DOT__busy = 0U;
        __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__a = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__b = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__c = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__d = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__e = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__f = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__g = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__h = 0U;
        vlSelfRef.tb_sm3_core__DOT__hash_out[0U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[0U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[1U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[1U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[2U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[2U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[3U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[3U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[4U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[4U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[5U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[5U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[6U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[6U];
        vlSelfRef.tb_sm3_core__DOT__hash_out[7U] = 
            Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[7U];
        vlSelfRef.tb_sm3_core__DOT__msg_id_out = 0U;
        vlSelfRef.tb_sm3_core__DOT__block_last_out = 0U;
        __VdlySet__tb_sm3_core__DOT__dut__DOT__w__v32 = 1U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__msg_id_q = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__last_q = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[0U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[0U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[1U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[1U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[2U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[2U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[3U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[3U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[4U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[4U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[5U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[5U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[6U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[6U];
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__hash_base[7U] 
            = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[7U];
    }
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__busy = __Vdly__tb_sm3_core__DOT__dut__DOT__busy;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx 
        = __Vdly__tb_sm3_core__DOT__dut__DOT__round_idx;
    if (__VdlySet__tb_sm3_core__DOT__dut__DOT__w__v0) {
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v0;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[1U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v1;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[2U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v2;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[3U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v3;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[4U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v4;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[5U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v5;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[6U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v6;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[7U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v7;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[8U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v8;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[9U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v9;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xaU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v10;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xbU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v11;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xcU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v12;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xdU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v13;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xeU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v14;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xfU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v15;
    }
    if (__VdlySet__tb_sm3_core__DOT__dut__DOT__w__v16) {
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v16;
    }
    if (__VdlySet__tb_sm3_core__DOT__dut__DOT__w__v17) {
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[1U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v17;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[2U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v18;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[3U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v19;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[4U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v20;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[5U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v21;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[6U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v22;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[7U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v23;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[8U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v24;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[9U] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v25;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xaU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v26;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xbU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v27;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xcU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v28;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xdU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v29;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xeU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v30;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xfU] 
            = __VdlyVal__tb_sm3_core__DOT__dut__DOT__w__v31;
    }
    if (__VdlySet__tb_sm3_core__DOT__dut__DOT__w__v32) {
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[1U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[2U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[3U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[4U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[5U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[6U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[7U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[8U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[9U] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xaU] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xbU] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xcU] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xdU] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xeU] = 0U;
        vlSelfRef.tb_sm3_core__DOT__dut__DOT__w[0xfU] = 0U;
    }
    tb_sm3_core__DOT__dut__DOT__wj = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
        [0U];
    tb_sm3_core__DOT__dut__DOT__wj4 = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
        [4U];
    tb_sm3_core__DOT__dut__DOT__wpj = (tb_sm3_core__DOT__dut__DOT__wj 
                                       ^ tb_sm3_core__DOT__dut__DOT__wj4);
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__wnext = (
                                                   (([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x 
                        = ((vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                            [0U] ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                            [7U]) ^ ([&]() {
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x 
                                    = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                                    [0xdU];
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout 
                                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x, 0xfU) 
                                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x, 0x11U));
                            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout));
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout 
                        = ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x 
                            ^ ([&]() {
                                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x 
                                        = vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x;
                                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout 
                                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x, 0xfU) 
                                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x, 0x11U));
                                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout)) 
                           ^ ([&]() {
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x 
                                    = vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x;
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout 
                                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x, 0x17U) 
                                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x, 9U));
                            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout) 
                                                    ^ 
                                                    ([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x 
                        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                        [3U];
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout 
                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x, 7U) 
                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x, 0x19U));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout)) 
                                                   ^ 
                                                   vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                                                   [0xaU]);
    tb_sm3_core__DOT__dut__DOT__tj = ((0x10U > (IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx))
                                       ? 0x79cc4519U
                                       : 0x7a879d8aU);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x 
        = tb_sm3_core__DOT__dut__DOT__tj;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n 
        = (0x1fU & __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout 
        = ((0U == __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n)
            ? __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x
            : (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n) 
               | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x, 
                               ((IData)(0x20U) - __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n))));
    tb_sm3_core__DOT__dut__DOT__tj_rot = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x, 0xcU) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x, 0x14U));
    tb_sm3_core__DOT__dut__DOT__a12 = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x 
        = ((tb_sm3_core__DOT__dut__DOT__a12 + vlSelfRef.tb_sm3_core__DOT__dut__DOT__e) 
           + tb_sm3_core__DOT__dut__DOT__tj_rot);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x, 7U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x, 0x19U));
    tb_sm3_core__DOT__dut__DOT__ss1 = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout;
    tb_sm3_core__DOT__dut__DOT__ss2 = (tb_sm3_core__DOT__dut__DOT__ss1 
                                       ^ tb_sm3_core__DOT__dut__DOT__a12);
    tb_sm3_core__DOT__dut__DOT__tt1 = (((([&]() {
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__c;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__b;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout 
                            = ((0x10U > (IData)(vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j))
                                ? ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                                    ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y) 
                                   ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)
                                : ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                                    & (vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                                       | vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)) 
                                   | (vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                                      & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)));
                    }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout) 
                                         + vlSelfRef.tb_sm3_core__DOT__dut__DOT__d) 
                                        + tb_sm3_core__DOT__dut__DOT__ss2) 
                                       + tb_sm3_core__DOT__dut__DOT__wpj);
    tb_sm3_core__DOT__dut__DOT__tt2 = (((([&]() {
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__g;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__f;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__e;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout 
                            = ((0x10U > (IData)(vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j))
                                ? ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                                    ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y) 
                                   ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z)
                                : ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                                    & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y) 
                                   | ((~ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x) 
                                      & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z)));
                    }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout) 
                                         + vlSelfRef.tb_sm3_core__DOT__dut__DOT__h) 
                                        + tb_sm3_core__DOT__dut__DOT__ss1) 
                                       + tb_sm3_core__DOT__dut__DOT__wj);
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__an = tb_sm3_core__DOT__dut__DOT__tt1;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__b;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x, 9U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x, 0x17U));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__cn = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__dn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__c;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x = tb_sm3_core__DOT__dut__DOT__tt2;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout 
        = ((__Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x 
            ^ ([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x 
                        = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout 
                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x, 9U) 
                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x, 0x17U));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout)) 
           ^ ([&]() {
                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x 
                    = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout 
                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x, 0x11U) 
                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x, 0xfU));
            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__en = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__e;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__f;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x, 0x13U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x, 0xdU));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__gn = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__hn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__g;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[0U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__hn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[1U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__gn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[2U] 
        = (IData)((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__en)) 
                    << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn))));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[3U] 
        = (IData)(((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__en)) 
                     << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn))) 
                   >> 0x20U));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[4U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__dn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[5U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__cn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[6U] 
        = (IData)((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__an)) 
                    << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn))));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[7U] 
        = (IData)(((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__an)) 
                     << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn))) 
                   >> 0x20U));
    vlSelfRef.tb_sm3_core__DOT__in_ready = (1U & (~ 
                                                  ((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__busy) 
                                                   | (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid))));
}

void Vtb_sm3_core___024root___timing_resume(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___timing_resume\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VtrigSched_h47e1613d__0.resume(
                                                   "@(posedge tb_sm3_core.clk)");
    }
    if ((4ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VtrigSched_h47e160fc__0.resume(
                                                   "@(negedge tb_sm3_core.clk)");
    }
    if ((8ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtb_sm3_core___024root___timing_commit(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___timing_commit\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((! (1ULL & vlSelfRef.__VactTriggered.word(0U)))) {
        vlSelfRef.__VtrigSched_h47e1613d__0.commit(
                                                   "@(posedge tb_sm3_core.clk)");
    }
    if ((! (4ULL & vlSelfRef.__VactTriggered.word(0U)))) {
        vlSelfRef.__VtrigSched_h47e160fc__0.commit(
                                                   "@(negedge tb_sm3_core.clk)");
    }
}

void Vtb_sm3_core___024root___eval_triggers__act(Vtb_sm3_core___024root* vlSelf);

bool Vtb_sm3_core___024root___eval_phase__act(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_phase__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<4> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb_sm3_core___024root___eval_triggers__act(vlSelf);
    Vtb_sm3_core___024root___timing_commit(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vtb_sm3_core___024root___timing_resume(vlSelf);
        Vtb_sm3_core___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtb_sm3_core___024root___eval_phase__nba(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_phase__nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtb_sm3_core___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__nba(Vtb_sm3_core___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__act(Vtb_sm3_core___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb_sm3_core___024root___eval(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtb_sm3_core___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("tb/tb_sm3_core.sv", 2, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelfRef.__VactIterCount))) {
#ifdef VL_DEBUG
                Vtb_sm3_core___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("tb/tb_sm3_core.sv", 2, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vtb_sm3_core___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vtb_sm3_core___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtb_sm3_core___024root___eval_debug_assertions(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_debug_assertions\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
