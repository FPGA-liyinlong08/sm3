// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vtb_sm3_core__pch.h"
#include "Vtb_sm3_core.h"
#include "Vtb_sm3_core___024root.h"

// FUNCTIONS
Vtb_sm3_core__Syms::~Vtb_sm3_core__Syms()
{
}

Vtb_sm3_core__Syms::Vtb_sm3_core__Syms(VerilatedContext* contextp, const char* namep, Vtb_sm3_core* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup module instances
    , TOP{this, namep}
{
        // Check resources
        Verilated::stackCheck(702);
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    // Setup scopes
    __Vscope_tb_sm3_core.configure(this, name(), "tb_sm3_core", "tb_sm3_core", "<null>", -9, VerilatedScope::SCOPE_OTHER);
    __Vscope_tb_sm3_core__unnamedblk1_2.configure(this, name(), "tb_sm3_core.unnamedblk1_2", "unnamedblk1_2", "<null>", -9, VerilatedScope::SCOPE_OTHER);
}
