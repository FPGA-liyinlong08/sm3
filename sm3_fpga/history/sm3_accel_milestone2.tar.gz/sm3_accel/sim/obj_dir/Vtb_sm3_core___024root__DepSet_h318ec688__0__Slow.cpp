// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_sm3_core.h for the primary calling header

#include "Vtb_sm3_core__pch.h"
#include "Vtb_sm3_core___024root.h"

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_static__TOP(Vtb_sm3_core___024root* vlSelf);

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_static(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_static\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtb_sm3_core___024root___eval_static__TOP(vlSelf);
}

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_static__TOP(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_static__TOP\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.tb_sm3_core__DOT__clk = 0U;
    vlSelfRef.tb_sm3_core__DOT__rst_n = 0U;
}

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_final(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_final\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__stl(Vtb_sm3_core___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vtb_sm3_core___024root___eval_phase__stl(Vtb_sm3_core___024root* vlSelf);

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_settle(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_settle\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vtb_sm3_core___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("tb/tb_sm3_core.sv", 2, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vtb_sm3_core___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__stl(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___dump_triggers__stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtb_sm3_core___024root___stl_sequent__TOP__0(Vtb_sm3_core___024root* vlSelf);

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_stl(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        Vtb_sm3_core___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vtb_sm3_core___024root___stl_sequent__TOP__0(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___stl_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wj;
    tb_sm3_core__DOT__dut__DOT__wj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wj4;
    tb_sm3_core__DOT__dut__DOT__wj4 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__wpj;
    tb_sm3_core__DOT__dut__DOT__wpj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tj;
    tb_sm3_core__DOT__dut__DOT__tj = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tj_rot;
    tb_sm3_core__DOT__dut__DOT__tj_rot = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__a12;
    tb_sm3_core__DOT__dut__DOT__a12 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__ss1;
    tb_sm3_core__DOT__dut__DOT__ss1 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__ss2;
    tb_sm3_core__DOT__dut__DOT__ss2 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tt1;
    tb_sm3_core__DOT__dut__DOT__tt1 = 0;
    IData/*31:0*/ tb_sm3_core__DOT__dut__DOT__tt2;
    tb_sm3_core__DOT__dut__DOT__tt2 = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x = 0;
    // Body
    vlSelfRef.tb_sm3_core__DOT__in_ready = (1U & (~ 
                                                  ((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__busy) 
                                                   | (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid))));
    tb_sm3_core__DOT__dut__DOT__wj = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
        [0U];
    tb_sm3_core__DOT__dut__DOT__wj4 = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
        [4U];
    tb_sm3_core__DOT__dut__DOT__wpj = (tb_sm3_core__DOT__dut__DOT__wj 
                                       ^ tb_sm3_core__DOT__dut__DOT__wj4);
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__wnext = (
                                                   (([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x 
                        = ((vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                            [0U] ^ vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                            [7U]) ^ ([&]() {
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x 
                                    = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                                    [0xdU];
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout 
                                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x, 0xfU) 
                                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x, 0x11U));
                            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout));
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout 
                        = ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x 
                            ^ ([&]() {
                                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x 
                                        = vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x;
                                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout 
                                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x, 0xfU) 
                                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x, 0x11U));
                                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout)) 
                           ^ ([&]() {
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x 
                                    = vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x;
                                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout 
                                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x, 0x17U) 
                                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x, 9U));
                            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout) 
                                                    ^ 
                                                    ([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x 
                        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                        [3U];
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout 
                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x, 7U) 
                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x, 0x19U));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout)) 
                                                   ^ 
                                                   vlSelfRef.tb_sm3_core__DOT__dut__DOT__w
                                                   [0xaU]);
    tb_sm3_core__DOT__dut__DOT__tj = ((0x10U > (IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx))
                                       ? 0x79cc4519U
                                       : 0x7a879d8aU);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x 
        = tb_sm3_core__DOT__dut__DOT__tj;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n 
        = (0x1fU & __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__sh);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout 
        = ((0U == __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n)
            ? __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x
            : (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n) 
               | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__x, 
                               ((IData)(0x20U) - __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__n))));
    tb_sm3_core__DOT__dut__DOT__tj_rot = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__5__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x, 0xcU) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__x, 0x14U));
    tb_sm3_core__DOT__dut__DOT__a12 = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__6__Vfuncout;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x 
        = ((tb_sm3_core__DOT__dut__DOT__a12 + vlSelfRef.tb_sm3_core__DOT__dut__DOT__e) 
           + tb_sm3_core__DOT__dut__DOT__tj_rot);
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x, 7U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__x, 0x19U));
    tb_sm3_core__DOT__dut__DOT__ss1 = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__7__Vfuncout;
    tb_sm3_core__DOT__dut__DOT__ss2 = (tb_sm3_core__DOT__dut__DOT__ss1 
                                       ^ tb_sm3_core__DOT__dut__DOT__a12);
    tb_sm3_core__DOT__dut__DOT__tt1 = (((([&]() {
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__c;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__b;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout 
                            = ((0x10U > (IData)(vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j))
                                ? ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                                    ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y) 
                                   ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)
                                : ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x 
                                    & (vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                                       | vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)) 
                                   | (vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y 
                                      & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z)));
                    }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout) 
                                         + vlSelfRef.tb_sm3_core__DOT__dut__DOT__d) 
                                        + tb_sm3_core__DOT__dut__DOT__ss2) 
                                       + tb_sm3_core__DOT__dut__DOT__wpj);
    tb_sm3_core__DOT__dut__DOT__tt2 = (((([&]() {
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_idx;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__g;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__f;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                            = vlSelfRef.tb_sm3_core__DOT__dut__DOT__e;
                        vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout 
                            = ((0x10U > (IData)(vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j))
                                ? ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                                    ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y) 
                                   ^ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z)
                                : ((vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x 
                                    & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y) 
                                   | ((~ vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x) 
                                      & vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z)));
                    }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout) 
                                         + vlSelfRef.tb_sm3_core__DOT__dut__DOT__h) 
                                        + tb_sm3_core__DOT__dut__DOT__ss1) 
                                       + tb_sm3_core__DOT__dut__DOT__wj);
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__an = tb_sm3_core__DOT__dut__DOT__tt1;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__a;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__b;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x, 9U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__x, 0x17U));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__cn = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__10__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__dn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__c;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x = tb_sm3_core__DOT__dut__DOT__tt2;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout 
        = ((__Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x 
            ^ ([&]() {
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x 
                        = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
                    vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout 
                        = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x, 9U) 
                           | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x, 0x17U));
                }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout)) 
           ^ ([&]() {
                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x 
                    = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__x;
                vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout 
                    = (VL_SHIFTL_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x, 0x11U) 
                       | VL_SHIFTR_III(32,32,32, vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x, 0xfU));
            }(), vlSelfRef.__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__en = __Vfunc_tb_sm3_core__DOT__dut__DOT__p0__11__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__e;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__f;
    __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout 
        = (VL_SHIFTL_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x, 0x13U) 
           | VL_SHIFTR_III(32,32,32, __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__x, 0xdU));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__gn = __Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__14__Vfuncout;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__hn = vlSelfRef.tb_sm3_core__DOT__dut__DOT__g;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[0U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__hn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[1U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__gn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[2U] 
        = (IData)((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__en)) 
                    << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn))));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[3U] 
        = (IData)(((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__en)) 
                     << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__fn))) 
                   >> 0x20U));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[4U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__dn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[5U] 
        = vlSelfRef.tb_sm3_core__DOT__dut__DOT__cn;
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[6U] 
        = (IData)((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__an)) 
                    << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn))));
    vlSelfRef.tb_sm3_core__DOT__dut__DOT__round_state_next[7U] 
        = (IData)(((((QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__an)) 
                     << 0x20U) | (QData)((IData)(vlSelfRef.tb_sm3_core__DOT__dut__DOT__bn))) 
                   >> 0x20U));
}

VL_ATTR_COLD void Vtb_sm3_core___024root___eval_triggers__stl(Vtb_sm3_core___024root* vlSelf);

VL_ATTR_COLD bool Vtb_sm3_core___024root___eval_phase__stl(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_phase__stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vtb_sm3_core___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        Vtb_sm3_core___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__act(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___dump_triggers__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge tb_sm3_core.clk)\n");
    }
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(negedge tb_sm3_core.rst_n)\n");
    }
    if ((4ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 2 is active: @(negedge tb_sm3_core.clk)\n");
    }
    if ((8ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 3 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__nba(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___dump_triggers__nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge tb_sm3_core.clk)\n");
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(negedge tb_sm3_core.rst_n)\n");
    }
    if ((4ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 2 is active: @(negedge tb_sm3_core.clk)\n");
    }
    if ((8ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 3 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtb_sm3_core___024root___ctor_var_reset(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___ctor_var_reset\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->tb_sm3_core__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__rst_n = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__in_valid = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__in_ready = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(512, vlSelf->tb_sm3_core__DOT__block_data);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__hash_in);
    vlSelf->tb_sm3_core__DOT__msg_id_in = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__block_last_in = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__out_valid = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__out_ready = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__hash_out);
    vlSelf->tb_sm3_core__DOT__msg_id_out = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__block_last_out = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__rc = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__msg_id_i = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__last_i = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__wait_cycles = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(512, vlSelf->tb_sm3_core__DOT__vec_block);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__vec_state);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__vec_expected);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__stable_hash);
    vlSelf->tb_sm3_core__DOT__stable_id = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__stable_last = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__dut__DOT__busy = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__dut__DOT__round_idx = VL_RAND_RESET_I(6);
    vlSelf->tb_sm3_core__DOT__dut__DOT__a = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__b = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__c = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__d = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__e = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__f = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__g = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__h = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__dut__DOT__hash_base);
    for (int __Vi0 = 0; __Vi0 < 16; ++__Vi0) {
        vlSelf->tb_sm3_core__DOT__dut__DOT__w[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->tb_sm3_core__DOT__dut__DOT__msg_id_q = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__last_q = VL_RAND_RESET_I(1);
    vlSelf->tb_sm3_core__DOT__dut__DOT__wnext = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__an = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__bn = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__cn = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__dn = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__en = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__fn = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__gn = VL_RAND_RESET_I(32);
    vlSelf->tb_sm3_core__DOT__dut__DOT__hn = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256, vlSelf->tb_sm3_core__DOT__dut__DOT__round_state_next);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__p1__0__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__1__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__2__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__3__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__4__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__y = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__z = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__ff__8__j = VL_RAND_RESET_I(6);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__y = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__z = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__gg__9__j = VL_RAND_RESET_I(6);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__12__x = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__Vfuncout = VL_RAND_RESET_I(32);
    vlSelf->__Vfunc_tb_sm3_core__DOT__dut__DOT__rol32__13__x = VL_RAND_RESET_I(32);
    vlSelf->__Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__tb_sm3_core__DOT__rst_n__0 = VL_RAND_RESET_I(1);
}
