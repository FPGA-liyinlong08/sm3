// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VTB_SM3_CORE__SYMS_H_
#define VERILATED_VTB_SM3_CORE__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vtb_sm3_core.h"

// INCLUDE MODULE CLASSES
#include "Vtb_sm3_core___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Vtb_sm3_core__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vtb_sm3_core* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vtb_sm3_core___024root         TOP;

    // SCOPE NAMES
    VerilatedScope __Vscope_tb_sm3_core;
    VerilatedScope __Vscope_tb_sm3_core__unnamedblk1_2;

    // CONSTRUCTORS
    Vtb_sm3_core__Syms(VerilatedContext* contextp, const char* namep, Vtb_sm3_core* modelp);
    ~Vtb_sm3_core__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
