// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_sm3_core.h for the primary calling header

#include "Vtb_sm3_core__pch.h"
#include "Vtb_sm3_core__Syms.h"
#include "Vtb_sm3_core___024root.h"

extern const VlWide<16>/*511:0*/ Vtb_sm3_core__ConstPool__CONST_h93e1b771_0;
extern const VlWide<8>/*255:0*/ Vtb_sm3_core__ConstPool__CONST_h9e67c271_0;

VL_INLINE_OPT VlCoroutine Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__0(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_initial__TOP__Vtiming__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ tb_sm3_core__DOT__fd;
    tb_sm3_core__DOT__fd = 0;
    IData/*31:0*/ tb_sm3_core__DOT__count;
    tb_sm3_core__DOT__count = 0;
    VlWide<6>/*191:0*/ __Vtemp_1;
    // Body
    vlSelfRef.tb_sm3_core__DOT__in_valid = 0U;
    vlSelfRef.tb_sm3_core__DOT__out_ready = 1U;
    vlSelfRef.tb_sm3_core__DOT__block_data[0U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0U];
    vlSelfRef.tb_sm3_core__DOT__block_data[1U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[1U];
    vlSelfRef.tb_sm3_core__DOT__block_data[2U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[2U];
    vlSelfRef.tb_sm3_core__DOT__block_data[3U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[3U];
    vlSelfRef.tb_sm3_core__DOT__block_data[4U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[4U];
    vlSelfRef.tb_sm3_core__DOT__block_data[5U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[5U];
    vlSelfRef.tb_sm3_core__DOT__block_data[6U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[6U];
    vlSelfRef.tb_sm3_core__DOT__block_data[7U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[7U];
    vlSelfRef.tb_sm3_core__DOT__block_data[8U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[8U];
    vlSelfRef.tb_sm3_core__DOT__block_data[9U] = Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[9U];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xaU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xaU];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xbU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xbU];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xcU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xcU];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xdU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xdU];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xeU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xeU];
    vlSelfRef.tb_sm3_core__DOT__block_data[0xfU] = 
        Vtb_sm3_core__ConstPool__CONST_h93e1b771_0[0xfU];
    vlSelfRef.tb_sm3_core__DOT__hash_in[0U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[0U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[1U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[1U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[2U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[2U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[3U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[3U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[4U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[4U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[5U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[5U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[6U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[6U];
    vlSelfRef.tb_sm3_core__DOT__hash_in[7U] = Vtb_sm3_core__ConstPool__CONST_h9e67c271_0[7U];
    vlSelfRef.tb_sm3_core__DOT__msg_id_in = 0U;
    vlSelfRef.tb_sm3_core__DOT__block_last_in = 0U;
    tb_sm3_core__DOT__count = 0U;
    co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb_sm3_core.clk)", 
                                                         "tb/tb_sm3_core.sv", 
                                                         50);
    co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb_sm3_core.clk)", 
                                                         "tb/tb_sm3_core.sv", 
                                                         50);
    co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb_sm3_core.clk)", 
                                                         "tb/tb_sm3_core.sv", 
                                                         50);
    co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb_sm3_core.clk)", 
                                                         "tb/tb_sm3_core.sv", 
                                                         50);
    co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(negedge tb_sm3_core.clk)", 
                                                         "tb/tb_sm3_core.sv", 
                                                         51);
    vlSelfRef.tb_sm3_core__DOT__rst_n = 1U;
    __Vtemp_1[0U] = 0x2e747874U;
    __Vtemp_1[1U] = 0x746f7273U;
    __Vtemp_1[2U] = 0x5f766563U;
    __Vtemp_1[3U] = 0x636f7265U;
    __Vtemp_1[4U] = 0x736d335fU;
    __Vtemp_1[5U] = 0x73696d2fU;
    tb_sm3_core__DOT__fd = VL_FOPEN_NN(VL_CVT_PACK_STR_NW(6, __Vtemp_1)
                                       , std::string{"r"});
    ;
    if (VL_UNLIKELY((0U == tb_sm3_core__DOT__fd))) {
        VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:55: Assertion failed in %Ntb_sm3_core: cannot open vector file\n",0,
                     64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name());
        VL_STOP_MT("tb/tb_sm3_core.sv", 55, "", false);
    }
    while ((! (tb_sm3_core__DOT__fd ? feof(VL_CVT_I_FP(tb_sm3_core__DOT__fd)) : true))) {
        vlSelfRef.tb_sm3_core__DOT__rc = VL_FSCANF_INX(tb_sm3_core__DOT__fd,"%x %x %x %# %#\n",0,
                                                       512,
                                                       &(vlSelfRef.tb_sm3_core__DOT__vec_block),
                                                       256,
                                                       &(vlSelfRef.tb_sm3_core__DOT__vec_state),
                                                       256,
                                                       &(vlSelfRef.tb_sm3_core__DOT__vec_expected),
                                                       32,
                                                       &(vlSelfRef.tb_sm3_core__DOT__msg_id_i),
                                                       32,
                                                       &(vlSelfRef.tb_sm3_core__DOT__last_i)) ;
        if ((5U != vlSelfRef.tb_sm3_core__DOT__rc)) {
            if (VL_UNLIKELY((! (tb_sm3_core__DOT__fd ? feof(VL_CVT_I_FP(tb_sm3_core__DOT__fd)) : true)))) {
                VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:61: Assertion failed in %Ntb_sm3_core: bad vector line after %0d cases, rc=%0d\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name(),32,
                             tb_sm3_core__DOT__count,
                             32,vlSelfRef.tb_sm3_core__DOT__rc);
                VL_STOP_MT("tb/tb_sm3_core.sv", 61, "", false);
            }
        } else {
            while ((1U & (~ (IData)(vlSelfRef.tb_sm3_core__DOT__in_ready)))) {
                co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                     nullptr, 
                                                                     "@(negedge tb_sm3_core.clk)", 
                                                                     "tb/tb_sm3_core.sv", 
                                                                     63);
            }
            vlSelfRef.tb_sm3_core__DOT__block_data[0U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0U];
            vlSelfRef.tb_sm3_core__DOT__block_data[1U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[1U];
            vlSelfRef.tb_sm3_core__DOT__block_data[2U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[2U];
            vlSelfRef.tb_sm3_core__DOT__block_data[3U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[3U];
            vlSelfRef.tb_sm3_core__DOT__block_data[4U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[4U];
            vlSelfRef.tb_sm3_core__DOT__block_data[5U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[5U];
            vlSelfRef.tb_sm3_core__DOT__block_data[6U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[6U];
            vlSelfRef.tb_sm3_core__DOT__block_data[7U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[7U];
            vlSelfRef.tb_sm3_core__DOT__block_data[8U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[8U];
            vlSelfRef.tb_sm3_core__DOT__block_data[9U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[9U];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xaU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xaU];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xbU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xbU];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xcU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xcU];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xdU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xdU];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xeU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xeU];
            vlSelfRef.tb_sm3_core__DOT__block_data[0xfU] 
                = vlSelfRef.tb_sm3_core__DOT__vec_block[0xfU];
            vlSelfRef.tb_sm3_core__DOT__hash_in[0U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[0U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[1U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[1U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[2U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[2U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[3U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[3U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[4U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[4U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[5U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[5U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[6U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[6U];
            vlSelfRef.tb_sm3_core__DOT__hash_in[7U] 
                = vlSelfRef.tb_sm3_core__DOT__vec_state[7U];
            vlSelfRef.tb_sm3_core__DOT__msg_id_in = vlSelfRef.tb_sm3_core__DOT__msg_id_i;
            vlSelfRef.tb_sm3_core__DOT__block_last_in 
                = (1U & vlSelfRef.tb_sm3_core__DOT__last_i);
            vlSelfRef.tb_sm3_core__DOT__in_valid = 1U;
            if ((0U == tb_sm3_core__DOT__count)) {
                vlSelfRef.tb_sm3_core__DOT__out_ready = 0U;
            }
            co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge tb_sm3_core.clk)", 
                                                                 "tb/tb_sm3_core.sv", 
                                                                 71);
            co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(negedge tb_sm3_core.clk)", 
                                                                 "tb/tb_sm3_core.sv", 
                                                                 72);
            vlSelfRef.tb_sm3_core__DOT__in_valid = 0U;
            vlSelfRef.tb_sm3_core__DOT__wait_cycles = 0U;
            while ((1U & (~ (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid)))) {
                co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                     nullptr, 
                                                                     "@(negedge tb_sm3_core.clk)", 
                                                                     "tb/tb_sm3_core.sv", 
                                                                     77);
                vlSelfRef.tb_sm3_core__DOT__wait_cycles 
                    = ((IData)(1U) + vlSelfRef.tb_sm3_core__DOT__wait_cycles);
                if (VL_UNLIKELY(VL_LTS_III(32, 0x46U, vlSelfRef.tb_sm3_core__DOT__wait_cycles))) {
                    VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:79: Assertion failed in %Ntb_sm3_core: timeout on vector %0d\n",0,
                                 64,VL_TIME_UNITED_Q(1000),
                                 -9,vlSymsp->name(),
                                 32,tb_sm3_core__DOT__count);
                    VL_STOP_MT("tb/tb_sm3_core.sv", 79, "", false);
                }
            }
            if (VL_UNLIKELY((0U != ((((((((vlSelfRef.tb_sm3_core__DOT__hash_out[0U] 
                                           ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[0U]) 
                                          | (vlSelfRef.tb_sm3_core__DOT__hash_out[1U] 
                                             ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[1U])) 
                                         | (vlSelfRef.tb_sm3_core__DOT__hash_out[2U] 
                                            ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[2U])) 
                                        | (vlSelfRef.tb_sm3_core__DOT__hash_out[3U] 
                                           ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[3U])) 
                                       | (vlSelfRef.tb_sm3_core__DOT__hash_out[4U] 
                                          ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[4U])) 
                                      | (vlSelfRef.tb_sm3_core__DOT__hash_out[5U] 
                                         ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[5U])) 
                                     | (vlSelfRef.tb_sm3_core__DOT__hash_out[6U] 
                                        ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[6U])) 
                                    | (vlSelfRef.tb_sm3_core__DOT__hash_out[7U] 
                                       ^ vlSelfRef.tb_sm3_core__DOT__vec_expected[7U]))))) {
                VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:83: Assertion failed in %Ntb_sm3_core: hash mismatch case=%0d msg=%0d\n got=%064x\n exp=%064x\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name(),32,
                             tb_sm3_core__DOT__count,
                             32,vlSelfRef.tb_sm3_core__DOT__msg_id_i,
                             256,vlSelfRef.tb_sm3_core__DOT__hash_out.data(),
                             256,vlSelfRef.tb_sm3_core__DOT__vec_expected.data());
                VL_STOP_MT("tb/tb_sm3_core.sv", 83, "", false);
            }
            if (VL_UNLIKELY((vlSelfRef.tb_sm3_core__DOT__msg_id_out 
                             != vlSelfRef.tb_sm3_core__DOT__msg_id_i))) {
                VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:86: Assertion failed in %Ntb_sm3_core: msg_id mismatch case=%0d got=%0# exp=%0d\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name(),32,
                             tb_sm3_core__DOT__count,
                             32,vlSelfRef.tb_sm3_core__DOT__msg_id_out,
                             32,vlSelfRef.tb_sm3_core__DOT__msg_id_i);
                VL_STOP_MT("tb/tb_sm3_core.sv", 86, "", false);
            }
            if (VL_UNLIKELY(((IData)(vlSelfRef.tb_sm3_core__DOT__block_last_out) 
                             != (1U & vlSelfRef.tb_sm3_core__DOT__last_i)))) {
                VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:88: Assertion failed in %Ntb_sm3_core: last mismatch case=%0d\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name(),32,
                             tb_sm3_core__DOT__count);
                VL_STOP_MT("tb/tb_sm3_core.sv", 88, "", false);
            }
            if ((0U == tb_sm3_core__DOT__count)) {
                vlSelfRef.tb_sm3_core__DOT__stable_hash[0U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[0U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[1U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[1U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[2U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[2U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[3U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[3U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[4U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[4U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[5U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[5U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[6U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[6U];
                vlSelfRef.tb_sm3_core__DOT__stable_hash[7U] 
                    = vlSelfRef.tb_sm3_core__DOT__hash_out[7U];
                vlSelfRef.tb_sm3_core__DOT__stable_id 
                    = vlSelfRef.tb_sm3_core__DOT__msg_id_out;
                vlSelfRef.tb_sm3_core__DOT__stable_last 
                    = vlSelfRef.tb_sm3_core__DOT__block_last_out;
                co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                     nullptr, 
                                                                     "@(negedge tb_sm3_core.clk)", 
                                                                     "tb/tb_sm3_core.sv", 
                                                                     96);
                if (VL_UNLIKELY((1U & ((((~ (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid)) 
                                         | (0U != (
                                                   (((((((vlSelfRef.tb_sm3_core__DOT__hash_out[0U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[0U]) 
                                                         | (vlSelfRef.tb_sm3_core__DOT__hash_out[1U] 
                                                            ^ 
                                                            vlSelfRef.tb_sm3_core__DOT__stable_hash[1U])) 
                                                        | (vlSelfRef.tb_sm3_core__DOT__hash_out[2U] 
                                                           ^ 
                                                           vlSelfRef.tb_sm3_core__DOT__stable_hash[2U])) 
                                                       | (vlSelfRef.tb_sm3_core__DOT__hash_out[3U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[3U])) 
                                                      | (vlSelfRef.tb_sm3_core__DOT__hash_out[4U] 
                                                         ^ 
                                                         vlSelfRef.tb_sm3_core__DOT__stable_hash[4U])) 
                                                     | (vlSelfRef.tb_sm3_core__DOT__hash_out[5U] 
                                                        ^ 
                                                        vlSelfRef.tb_sm3_core__DOT__stable_hash[5U])) 
                                                    | (vlSelfRef.tb_sm3_core__DOT__hash_out[6U] 
                                                       ^ 
                                                       vlSelfRef.tb_sm3_core__DOT__stable_hash[6U])) 
                                                   | (vlSelfRef.tb_sm3_core__DOT__hash_out[7U] 
                                                      ^ 
                                                      vlSelfRef.tb_sm3_core__DOT__stable_hash[7U])))) 
                                        | (vlSelfRef.tb_sm3_core__DOT__msg_id_out 
                                           != vlSelfRef.tb_sm3_core__DOT__stable_id)) 
                                       | ((IData)(vlSelfRef.tb_sm3_core__DOT__block_last_out) 
                                          != (IData)(vlSelfRef.tb_sm3_core__DOT__stable_last)))))) {
                    VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:99: Assertion failed in %Ntb_sm3_core.unnamedblk1_2: output changed under backpressure\n",0,
                                 64,VL_TIME_UNITED_Q(1000),
                                 -9,vlSymsp->name());
                    VL_STOP_MT("tb/tb_sm3_core.sv", 99, "", false);
                }
                co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                     nullptr, 
                                                                     "@(negedge tb_sm3_core.clk)", 
                                                                     "tb/tb_sm3_core.sv", 
                                                                     96);
                if (VL_UNLIKELY((1U & ((((~ (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid)) 
                                         | (0U != (
                                                   (((((((vlSelfRef.tb_sm3_core__DOT__hash_out[0U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[0U]) 
                                                         | (vlSelfRef.tb_sm3_core__DOT__hash_out[1U] 
                                                            ^ 
                                                            vlSelfRef.tb_sm3_core__DOT__stable_hash[1U])) 
                                                        | (vlSelfRef.tb_sm3_core__DOT__hash_out[2U] 
                                                           ^ 
                                                           vlSelfRef.tb_sm3_core__DOT__stable_hash[2U])) 
                                                       | (vlSelfRef.tb_sm3_core__DOT__hash_out[3U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[3U])) 
                                                      | (vlSelfRef.tb_sm3_core__DOT__hash_out[4U] 
                                                         ^ 
                                                         vlSelfRef.tb_sm3_core__DOT__stable_hash[4U])) 
                                                     | (vlSelfRef.tb_sm3_core__DOT__hash_out[5U] 
                                                        ^ 
                                                        vlSelfRef.tb_sm3_core__DOT__stable_hash[5U])) 
                                                    | (vlSelfRef.tb_sm3_core__DOT__hash_out[6U] 
                                                       ^ 
                                                       vlSelfRef.tb_sm3_core__DOT__stable_hash[6U])) 
                                                   | (vlSelfRef.tb_sm3_core__DOT__hash_out[7U] 
                                                      ^ 
                                                      vlSelfRef.tb_sm3_core__DOT__stable_hash[7U])))) 
                                        | (vlSelfRef.tb_sm3_core__DOT__msg_id_out 
                                           != vlSelfRef.tb_sm3_core__DOT__stable_id)) 
                                       | ((IData)(vlSelfRef.tb_sm3_core__DOT__block_last_out) 
                                          != (IData)(vlSelfRef.tb_sm3_core__DOT__stable_last)))))) {
                    VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:99: Assertion failed in %Ntb_sm3_core.unnamedblk1_2: output changed under backpressure\n",0,
                                 64,VL_TIME_UNITED_Q(1000),
                                 -9,vlSymsp->name());
                    VL_STOP_MT("tb/tb_sm3_core.sv", 99, "", false);
                }
                co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                     nullptr, 
                                                                     "@(negedge tb_sm3_core.clk)", 
                                                                     "tb/tb_sm3_core.sv", 
                                                                     96);
                if (VL_UNLIKELY((1U & ((((~ (IData)(vlSelfRef.tb_sm3_core__DOT__out_valid)) 
                                         | (0U != (
                                                   (((((((vlSelfRef.tb_sm3_core__DOT__hash_out[0U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[0U]) 
                                                         | (vlSelfRef.tb_sm3_core__DOT__hash_out[1U] 
                                                            ^ 
                                                            vlSelfRef.tb_sm3_core__DOT__stable_hash[1U])) 
                                                        | (vlSelfRef.tb_sm3_core__DOT__hash_out[2U] 
                                                           ^ 
                                                           vlSelfRef.tb_sm3_core__DOT__stable_hash[2U])) 
                                                       | (vlSelfRef.tb_sm3_core__DOT__hash_out[3U] 
                                                          ^ 
                                                          vlSelfRef.tb_sm3_core__DOT__stable_hash[3U])) 
                                                      | (vlSelfRef.tb_sm3_core__DOT__hash_out[4U] 
                                                         ^ 
                                                         vlSelfRef.tb_sm3_core__DOT__stable_hash[4U])) 
                                                     | (vlSelfRef.tb_sm3_core__DOT__hash_out[5U] 
                                                        ^ 
                                                        vlSelfRef.tb_sm3_core__DOT__stable_hash[5U])) 
                                                    | (vlSelfRef.tb_sm3_core__DOT__hash_out[6U] 
                                                       ^ 
                                                       vlSelfRef.tb_sm3_core__DOT__stable_hash[6U])) 
                                                   | (vlSelfRef.tb_sm3_core__DOT__hash_out[7U] 
                                                      ^ 
                                                      vlSelfRef.tb_sm3_core__DOT__stable_hash[7U])))) 
                                        | (vlSelfRef.tb_sm3_core__DOT__msg_id_out 
                                           != vlSelfRef.tb_sm3_core__DOT__stable_id)) 
                                       | ((IData)(vlSelfRef.tb_sm3_core__DOT__block_last_out) 
                                          != (IData)(vlSelfRef.tb_sm3_core__DOT__stable_last)))))) {
                    VL_WRITEF_NX("[%0t] %%Fatal: tb_sm3_core.sv:99: Assertion failed in %Ntb_sm3_core.unnamedblk1_2: output changed under backpressure\n",0,
                                 64,VL_TIME_UNITED_Q(1000),
                                 -9,vlSymsp->name());
                    VL_STOP_MT("tb/tb_sm3_core.sv", 99, "", false);
                }
                vlSelfRef.tb_sm3_core__DOT__out_ready = 1U;
            }
            co_await vlSelfRef.__VtrigSched_h47e1613d__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge tb_sm3_core.clk)", 
                                                                 "tb/tb_sm3_core.sv", 
                                                                 104);
            co_await vlSelfRef.__VtrigSched_h47e160fc__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(negedge tb_sm3_core.clk)", 
                                                                 "tb/tb_sm3_core.sv", 
                                                                 105);
            tb_sm3_core__DOT__count = ((IData)(1U) 
                                       + tb_sm3_core__DOT__count);
        }
    }
    VL_FCLOSE_I(tb_sm3_core__DOT__fd); VL_WRITEF_NX("SM3 CORE PASS: %0d compression vectors\n",0,
                                                    32,
                                                    tb_sm3_core__DOT__count);
    VL_FINISH_MT("tb/tb_sm3_core.sv", 112, "");
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_sm3_core___024root___dump_triggers__act(Vtb_sm3_core___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb_sm3_core___024root___eval_triggers__act(Vtb_sm3_core___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb_sm3_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_sm3_core___024root___eval_triggers__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered.set(0U, ((IData)(vlSelfRef.tb_sm3_core__DOT__clk) 
                                       & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0))));
    vlSelfRef.__VactTriggered.set(1U, ((~ (IData)(vlSelfRef.tb_sm3_core__DOT__rst_n)) 
                                       & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__rst_n__0)));
    vlSelfRef.__VactTriggered.set(2U, ((~ (IData)(vlSelfRef.tb_sm3_core__DOT__clk)) 
                                       & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0)));
    vlSelfRef.__VactTriggered.set(3U, vlSelfRef.__VdlySched.awaitingCurrentTime());
    vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__clk__0 
        = vlSelfRef.tb_sm3_core__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb_sm3_core__DOT__rst_n__0 
        = vlSelfRef.tb_sm3_core__DOT__rst_n;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb_sm3_core___024root___dump_triggers__act(vlSelf);
    }
#endif
}
