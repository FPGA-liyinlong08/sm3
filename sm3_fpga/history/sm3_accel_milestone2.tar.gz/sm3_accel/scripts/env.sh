#!/usr/bin/env bash
ROOT="/mnt/data/sm3_dev_env"
export PATH="$ROOT/venv/bin:$ROOT/verilator-root/usr/bin:$PATH"
export VERILATOR_ROOT="$ROOT/verilator-root/usr/share/verilator"
