# SM3 FPGA accelerator — verification baseline

Current milestone:
- Python dependency-free SM3 Golden Model
- iterative `sm3_core`, 1 round/cycle
- 16×32-bit sliding W window
- 512-bit compression-block input interface
- output backpressure support
- Message ID / last tag passthrough

## Verified environment

- Verilator 5.032: standalone SystemVerilog regression works
- cocotb 2.1.0: installed, but its Verilator backend requires Verilator >= 5.036

## Run now with Verilator 5.032

```bash
./scripts/run_core_verilator.sh
```

The regression includes official-known SM3 vectors, padding boundary-derived chained blocks,
and random compression-state/block vectors.

## Run cocotb after Verilator upgrade

```bash
./scripts/run_core_cocotb.sh
```

## Directory layout

- `model/sm3_ref.py` — Golden Model
- `rtl/core/sm3_core.sv` — iterative compression core
- `tb/gen_vectors.py` — standalone vector generator
- `tb/tb_sm3_core.sv` — standalone Verilator testbench
- `tb/test_sm3_core.py` — cocotb regression
- `scripts/env.sh` — local simulator environment
