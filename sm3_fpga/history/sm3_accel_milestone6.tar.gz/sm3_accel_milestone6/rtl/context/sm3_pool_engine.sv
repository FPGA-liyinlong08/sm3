module sm3_pool_engine #(
    parameter int CORE_NUM   = 8,
    parameter int CTX_NUM    = 32,
    parameter int MSG_ID_W   = 32,
    parameter int FAST_DEPTH = 32,
    parameter int POOL_DEPTH = 256,
    parameter int FAST_QUOTA = 3,
    parameter int STICKY_QUANTUM_BUSY = 2,
    parameter int STICKY_QUANTUM_IDLE = 8,
    parameter int FAST_WATERMARK = 1,
    parameter int FAST_PRESSURE_HOLD = 32,
    parameter int CTX_ID_W   = (CTX_NUM <= 1) ? 1 : $clog2(CTX_NUM),
    parameter int CORE_ID_W  = (CORE_NUM <= 1) ? 1 : $clog2(CORE_NUM),
    parameter int CTX_RR_W   = (CTX_NUM <= 1) ? 1 : $clog2(CTX_NUM),
    parameter int FAST_PTR_W = (FAST_DEPTH <= 1) ? 1 : $clog2(FAST_DEPTH),
    parameter int FAST_CNT_W = $clog2(FAST_DEPTH + 1),
    parameter int POOL_SLOT_W = (POOL_DEPTH <= 1) ? 1 : $clog2(POOL_DEPTH),
    parameter int POOL_CNT_W  = $clog2(POOL_DEPTH + 1),
    parameter int FAST_BURST_W = (FAST_QUOTA <= 1) ? 1 : $clog2(FAST_QUOTA + 1),
    parameter int MAX_STICKY_QUANTUM = (STICKY_QUANTUM_IDLE > STICKY_QUANTUM_BUSY)
                                     ? STICKY_QUANTUM_IDLE : STICKY_QUANTUM_BUSY,
    parameter int QUANTUM_W = (MAX_STICKY_QUANTUM <= 1) ? 1 : $clog2(MAX_STICKY_QUANTUM + 1),
    parameter int PRESSURE_W = (FAST_PRESSURE_HOLD <= 1) ? 1 : $clog2(FAST_PRESSURE_HOLD + 1),
    parameter int TAG_W      = 1 + MSG_ID_W + CTX_ID_W
) (
    input  logic                     clk,
    input  logic                     rst_n,

    input  logic                     block_valid,
    output logic                     block_ready,
    input  logic [511:0]             block_data,
    input  logic [CTX_ID_W-1:0]      block_ctx_id_in,
    input  logic [MSG_ID_W-1:0]      msg_id_in,
    input  logic                     block_first_in,
    input  logic                     block_last_in,

    output logic                     result_valid,
    input  logic                     result_ready,
    output logic [255:0]             digest_out,
    output logic [MSG_ID_W-1:0]      msg_id_out,
    output logic [CTX_ID_W-1:0]      ctx_id_out,
    output logic                     result_fast,

    output logic [CORE_NUM-1:0]      core_occupied,
    output logic [CTX_NUM-1:0]       ctx_valid_bitmap,
    output logic [CTX_NUM-1:0]       ctx_pending_bitmap,
    output logic [CTX_NUM-1:0]       ctx_inflight_bitmap,
    output logic [FAST_CNT_W-1:0]    fast_level,
    output logic [POOL_CNT_W-1:0]    pool_free_count,
    output logic                     pool_init_done,

    output logic                     dbg_dispatch_valid,
    output logic                     dbg_dispatch_fast,
    output logic [CTX_ID_W-1:0]      dbg_dispatch_ctx_id,
    output logic                     dbg_commit_valid,
    output logic                     dbg_commit_fast,
    output logic [CTX_ID_W-1:0]      dbg_commit_ctx_id,
    output logic                     dbg_commit_last,
    output logic                     dbg_sticky_valid
);

    localparam logic [255:0] SM3_IV =
        256'h7380166f4914b2b9172442d7da8a0600a96f30bc163138aae38dee4db0fb0e4e;

    // ------------------------------------------------------------------
    // Per-message context metadata. Payload blocks are no longer stored in
    // the context. Each context owns a linked list of slots in the global pool.
    // ------------------------------------------------------------------
    logic [CTX_NUM-1:0] ctx_valid;
    logic [CTX_NUM-1:0] ctx_pending_valid;
    logic [CTX_NUM-1:0] ctx_inflight;
    logic [CTX_NUM-1:0] ctx_last_accepted;
    logic [MSG_ID_W-1:0] ctx_msg_id [0:CTX_NUM-1];
    logic [POOL_SLOT_W-1:0] ctx_head [0:CTX_NUM-1];
    logic [POOL_SLOT_W-1:0] ctx_tail [0:CTX_NUM-1];

    assign ctx_valid_bitmap    = ctx_valid;
    assign ctx_pending_bitmap  = ctx_pending_valid;
    assign ctx_inflight_bitmap = ctx_inflight;

    // Hash state remains one entry per active multi-block message.
    (* ram_style = "block" *) logic [255:0] hash_mem [0:CTX_NUM-1];
    logic hash_rd_en;
    logic [CTX_ID_W-1:0] hash_rd_addr;
    logic [255:0] hash_rd_state;
    logic hash_wr_en;
    logic [CTX_ID_W-1:0] hash_wr_addr;
    logic [255:0] hash_wr_data;

    // ------------------------------------------------------------------
    // Fast FIFO for single-block messages.
    // ------------------------------------------------------------------
    (* ram_style = "distributed" *) logic [511:0]        fast_block_mem [0:FAST_DEPTH-1];
    (* ram_style = "distributed" *) logic [MSG_ID_W-1:0] fast_msg_mem   [0:FAST_DEPTH-1];
    (* ram_style = "distributed" *) logic [CTX_ID_W-1:0] fast_ctx_mem   [0:FAST_DEPTH-1];
    logic [FAST_PTR_W-1:0] fast_wr_ptr, fast_rd_ptr;
    logic [FAST_CNT_W-1:0] fast_count;
    logic fast_push, fast_pop;
    logic fast_full, fast_empty;

    assign fast_full  = (fast_count == FAST_CNT_W'(FAST_DEPTH));
    assign fast_empty = (fast_count == 0);
    assign fast_level = fast_count;

    // ------------------------------------------------------------------
    // Global multi-block pool.
    // ------------------------------------------------------------------
    logic                  pool_alloc_valid;
    logic                  pool_alloc_ready;
    logic [POOL_SLOT_W-1:0] pool_alloc_slot;
    logic                  pool_free_valid;
    logic [POOL_SLOT_W-1:0] pool_free_slot;
    logic                  pool_link_wr_en;
    logic [POOL_SLOT_W-1:0] pool_link_wr_slot;
    logic [POOL_SLOT_W-1:0] pool_link_wr_next;
    logic [POOL_SLOT_W-1:0] pool_link_rd_slot;
    logic [POOL_SLOT_W-1:0] pool_link_rd_next;
    logic                  pool_rd_en;
    logic [POOL_SLOT_W-1:0] pool_rd_slot;
    logic [511:0]          pool_rd_block;
    logic                  pool_rd_first;
    logic                  pool_rd_last;

    localparam int CTX_EXT_W = CTX_ID_W + 1;

    logic [CTX_ID_W-1:0] input_ctx_idx;
    logic input_ctx_in_range;
    logic input_is_fast;
    logic input_multi_ok;
    logic multi_push;
    logic [CTX_ID_W-1:0] push_ctx_idx;

    always_comb begin
        input_ctx_idx = block_ctx_id_in;
        input_ctx_in_range = ({1'b0, block_ctx_id_in} < CTX_EXT_W'(CTX_NUM));
        input_is_fast = block_first_in && block_last_in;
        input_multi_ok = 1'b0;

        if (!input_is_fast && input_ctx_in_range) begin
            if (block_first_in)
                input_multi_ok = !ctx_valid[input_ctx_idx];
            else
                input_multi_ok = ctx_valid[input_ctx_idx]
                              && (ctx_msg_id[input_ctx_idx] == msg_id_in)
                              && !ctx_last_accepted[input_ctx_idx];
        end

        if (input_is_fast)
            block_ready = !fast_full;
        else
            block_ready = input_multi_ok && pool_alloc_ready;
    end

    assign fast_push = block_valid && block_ready && input_is_fast;
    assign multi_push = block_valid && block_ready && !input_is_fast;
    assign push_ctx_idx = input_ctx_idx;
    assign pool_alloc_valid = block_valid && !input_is_fast && input_multi_ok;

    // ------------------------------------------------------------------
    // Core bank and launch pipeline.
    // ------------------------------------------------------------------
    logic [CORE_NUM-1:0] core_in_valid;
    logic [CORE_NUM-1:0] core_in_ready;
    logic [CORE_NUM-1:0] core_out_valid;
    logic [CORE_NUM-1:0] core_out_ready;
    logic [CORE_NUM-1:0] core_reserved;
    logic [255:0]        core_hash_out [0:CORE_NUM-1];
    logic [TAG_W-1:0]    core_tag_out  [0:CORE_NUM-1];
    logic                core_last_out [0:CORE_NUM-1];

    logic [CORE_ID_W-1:0] sched_core_sel;
    logic                 sched_core_found;
    logic [CTX_ID_W-1:0]  sched_ctx_sel;
    logic                 sched_ctx_found;
    logic [CTX_EXT_W-1:0] sched_ctx_scan;
    logic [CTX_RR_W-1:0] ctx_rr_ptr;
    logic   sched_use_fast;
    logic   sched_fire;
    logic   launch_valid;
    logic   launch_is_fast;
    logic [CTX_ID_W-1:0] launch_ctx_id;
    logic [MSG_ID_W-1:0] launch_msg_id;
    logic [511:0]        launch_fast_block;
    logic [CORE_ID_W-1:0] launch_core_id;
    logic   launch_fire;
    logic   launch_pipe_ready;
    logic [FAST_BURST_W-1:0] fast_burst_count;
    logic [QUANTUM_W-1:0] core_quantum [0:CORE_NUM-1];
    logic                  launch_hash_bypass;
    logic [255:0]          launch_hash_value;
    logic                  sticky_issue;
    logic [QUANTUM_W-1:0] sticky_quantum_limit;
    logic [PRESSURE_W-1:0] fast_pressure_count;

    logic [511:0]      core_launch_block;
    logic [255:0]      core_launch_hash;
    logic              core_launch_last;
    logic [TAG_W-1:0] core_launch_tag;

    assign sticky_quantum_limit = ((fast_count >= FAST_CNT_W'(FAST_WATERMARK))
                                  || (fast_pressure_count != 0))
                                ? QUANTUM_W'(STICKY_QUANTUM_BUSY)
                                : QUANTUM_W'(STICKY_QUANTUM_IDLE);

    assign launch_fire       = launch_valid && core_in_ready[launch_core_id];
    assign launch_pipe_ready = !launch_valid || launch_fire;

    always_comb begin
        sched_core_sel   = '0;
        sched_core_found = 1'b0;
        sched_ctx_sel    = '0;
        sched_ctx_found  = 1'b0;
        sched_ctx_scan   = '0;
        sched_use_fast = 1'b0;

        if (launch_pipe_ready) begin
            for (int k = 0; k < CORE_NUM; k = k + 1) begin
                if (!sched_core_found && core_in_ready[k] && !core_reserved[k]) begin
                    sched_core_sel   = CORE_ID_W'(k);
                    sched_core_found = 1'b1;
                end
            end

            // Round-robin across ready contexts. Fixed low-ID priority can
            // otherwise starve older high-ID messages under sustained load.
            for (int off = 0; off < CTX_NUM; off = off + 1) begin
                sched_ctx_scan = {1'b0, ctx_rr_ptr} + CTX_EXT_W'(off);
                if (sched_ctx_scan >= CTX_EXT_W'(CTX_NUM))
                    sched_ctx_scan = sched_ctx_scan - CTX_EXT_W'(CTX_NUM);
                if (!sched_ctx_found
                    && ctx_valid[sched_ctx_scan[CTX_ID_W-1:0]]
                    && ctx_pending_valid[sched_ctx_scan[CTX_ID_W-1:0]]
                    && !ctx_inflight[sched_ctx_scan[CTX_ID_W-1:0]]) begin
                    sched_ctx_sel   = sched_ctx_scan[CTX_ID_W-1:0];
                    sched_ctx_found = 1'b1;
                end
            end

            if (!fast_empty && !sched_ctx_found)
                sched_use_fast = 1'b1;
            else if (!fast_empty && (fast_burst_count < FAST_BURST_W'(FAST_QUOTA)))
                sched_use_fast = 1'b1;
        end
    end

    // ------------------------------------------------------------------
    // Completion arbitration.
    // ------------------------------------------------------------------
    logic [CORE_ID_W-1:0] commit_core_sel;
    logic                 commit_core_found;
    logic                 commit_ctx_in_range;
    logic   commit_fire;
    logic   commit_last;
    logic   commit_is_fast;
    logic [CTX_ID_W-1:0] commit_ctx_id;
    logic [MSG_ID_W-1:0] commit_msg_id;
    logic [255:0] commit_hash;
    logic result_slot_available;

    assign result_slot_available = !result_valid || result_ready;

    always_comb begin
        commit_core_sel   = '0;
        commit_core_found = 1'b0;
        core_out_ready  = '0;
        for (int k = 0; k < CORE_NUM; k = k + 1) begin
            if (!commit_core_found && core_out_valid[k]) begin
                commit_core_sel   = CORE_ID_W'(k);
                commit_core_found = 1'b1;
            end
        end

        if (commit_core_found) begin
            if ((!core_tag_out[commit_core_sel][TAG_W-1]
                 && !core_last_out[commit_core_sel]) || result_slot_available)
                core_out_ready[commit_core_sel] = 1'b1;
        end
    end

    always_comb begin
        commit_fire    = 1'b0;
        commit_last    = 1'b0;
        commit_is_fast = 1'b0;
        commit_ctx_id  = '0;
        commit_msg_id  = '0;
        commit_hash    = '0;
        commit_ctx_in_range = 1'b0;

        if (commit_core_found) begin
            commit_fire    = core_out_valid[commit_core_sel] && core_out_ready[commit_core_sel];
            commit_last    = core_last_out[commit_core_sel];
            commit_hash    = core_hash_out[commit_core_sel];
            commit_is_fast = core_tag_out[commit_core_sel][TAG_W-1];
            commit_msg_id  = core_tag_out[commit_core_sel][CTX_ID_W +: MSG_ID_W];
            commit_ctx_id  = core_tag_out[commit_core_sel][CTX_ID_W-1:0];
            commit_ctx_in_range = ({1'b0, core_tag_out[commit_core_sel][CTX_ID_W-1:0]}
                                   < CTX_EXT_W'(CTX_NUM));
        end
    end

    // Sticky continuation consumes the next queued slot directly on the core
    // that just completed, bypassing a hash-RAM write/read round trip.
    always_comb begin
        sticky_issue = 1'b0;
        if (launch_pipe_ready
            && commit_fire
            && !commit_is_fast
            && !commit_last
            && commit_ctx_in_range
            && ctx_pending_valid[commit_ctx_id]
            && (core_quantum[commit_core_sel] < sticky_quantum_limit))
            sticky_issue = 1'b1;
    end

    assign sched_fire = !sticky_issue
                     && sched_core_found
                     && (sched_use_fast || sched_ctx_found);
    assign fast_pop = sched_fire && sched_use_fast;

    // One context queue slot is popped whenever a normal context dispatch or a
    // sticky continuation is selected. The slot returns to the global free list
    // immediately after the synchronous payload read is launched.
    logic ctx_pop;
    logic [CTX_ID_W-1:0] pop_ctx_idx;
    logic [POOL_SLOT_W-1:0] pop_slot;
    logic pop_single_old;
    logic push_pop_same_ctx;

    always_comb begin
        ctx_pop = sticky_issue || (sched_fire && !sched_use_fast);
        pop_ctx_idx = '0;
        if (sticky_issue)
            pop_ctx_idx = commit_ctx_id;
        else if (sched_fire && !sched_use_fast)
            pop_ctx_idx = sched_ctx_sel;

        pop_slot = '0;
        pop_single_old = 1'b0;
        if (ctx_pop) begin
            pop_slot = ctx_head[pop_ctx_idx];
            pop_single_old = (ctx_head[pop_ctx_idx] == ctx_tail[pop_ctx_idx]);
        end
    end

    assign push_pop_same_ctx = multi_push && ctx_pop && (push_ctx_idx == pop_ctx_idx);

    assign pool_rd_en   = ctx_pop;
    assign pool_rd_slot = pop_slot;
    assign pool_free_valid = ctx_pop;
    assign pool_free_slot  = pop_slot;
    assign pool_link_rd_slot = pop_slot;

    // Link the previous tail to a newly allocated slot, except for the special
    // one-element pop+push case where the old tail is being removed entirely.
    assign pool_link_wr_en = multi_push
                           && ctx_pending_valid[push_ctx_idx]
                           && !(push_pop_same_ctx && pop_single_old);
    assign pool_link_wr_slot = ctx_tail[push_ctx_idx];
    assign pool_link_wr_next = pool_alloc_slot;

    // Hash RAM read is needed for normal context dispatch only. Sticky uses the
    // completion result directly as hash_in.
    assign hash_rd_en   = sched_fire && !sched_use_fast;
    assign hash_rd_addr = sched_ctx_sel;
    assign hash_wr_en   = commit_fire && !commit_is_fast && !commit_last && !sticky_issue;
    assign hash_wr_addr = commit_ctx_id;
    assign hash_wr_data = commit_hash;

    always_ff @(posedge clk) begin
        if (hash_wr_en)
            hash_mem[hash_wr_addr] <= hash_wr_data;
        if (hash_rd_en)
            hash_rd_state <= hash_mem[hash_rd_addr];
    end

    always_comb begin
        core_in_valid = '0;
        if (launch_valid)
            core_in_valid[launch_core_id] = 1'b1;

        core_launch_block = launch_is_fast ? launch_fast_block : pool_rd_block;
        core_launch_hash  = launch_is_fast ? SM3_IV
                         : (launch_hash_bypass ? launch_hash_value
                         : (pool_rd_first ? SM3_IV : hash_rd_state));
        core_launch_last  = launch_is_fast ? 1'b1 : pool_rd_last;
        core_launch_tag   = {launch_is_fast,
                             (launch_is_fast ? launch_msg_id : {MSG_ID_W{1'b0}}),
                             launch_ctx_id};
    end

    assign dbg_dispatch_valid  = launch_fire;
    assign dbg_dispatch_fast   = launch_fire && launch_is_fast;
    assign dbg_dispatch_ctx_id = launch_ctx_id;
    assign dbg_commit_valid    = commit_fire;
    assign dbg_commit_fast     = commit_fire && commit_is_fast;
    assign dbg_commit_ctx_id   = commit_ctx_id;
    assign dbg_commit_last     = commit_last;
    assign dbg_sticky_valid    = sticky_issue;

    always_comb begin
        for (int k = 0; k < CORE_NUM; k = k + 1)
            core_occupied[k] = (~core_in_ready[k]) | core_reserved[k];
    end

    // Fast FIFO storage is deliberately isolated from reset/control logic so
    // synthesis can infer distributed RAM instead of 32 x 550 bits of FFs.
    always_ff @(posedge clk) begin
        if (fast_push) begin
            fast_block_mem[fast_wr_ptr] <= block_data;
            fast_msg_mem[fast_wr_ptr]   <= msg_id_in;
            fast_ctx_mem[fast_wr_ptr]   <= block_ctx_id_in;
        end
    end

    // ------------------------------------------------------------------
    // Sequential metadata/control state.
    // ------------------------------------------------------------------
    integer i;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ctx_valid         <= '0;
            ctx_pending_valid <= '0;
            ctx_inflight      <= '0;
            ctx_last_accepted <= '0;
            core_reserved     <= '0;
            launch_valid      <= 1'b0;
            launch_is_fast    <= 1'b0;
            launch_ctx_id     <= '0;
            launch_msg_id     <= '0;
            launch_fast_block <= '0;
            launch_core_id    <= '0;
            launch_hash_bypass <= 1'b0;
            launch_hash_value  <= '0;
            fast_wr_ptr       <= '0;
            fast_rd_ptr       <= '0;
            fast_count        <= '0;
            fast_burst_count  <= '0;
            ctx_rr_ptr         <= '0;
            fast_pressure_count <= '0;
            result_valid <= 1'b0;
            digest_out   <= '0;
            msg_id_out   <= '0;
            ctx_id_out   <= '0;
            result_fast  <= 1'b0;

            for (i = 0; i < CTX_NUM; i = i + 1) begin
                ctx_msg_id[i] <= '0;
                ctx_head[i]   <= '0;
                ctx_tail[i]   <= '0;
            end
            for (i = 0; i < CORE_NUM; i = i + 1)
                core_quantum[i] <= '0;
        end else begin
            if (result_valid && result_ready)
                result_valid <= 1'b0;

            if (fast_push) begin
                if (fast_wr_ptr == FAST_PTR_W'(FAST_DEPTH-1))
                    fast_wr_ptr <= '0;
                else
                    fast_wr_ptr <= fast_wr_ptr + 1'b1;
            end

            // Context ownership and message identity are established on the
            // first multi-block enqueue. Later blocks may accumulate freely in
            // the global pool while an earlier block is inflight.
            if (multi_push) begin
                if (block_first_in) begin
                    ctx_valid[push_ctx_idx]         <= 1'b1;
                    ctx_msg_id[push_ctx_idx]        <= msg_id_in;
                    ctx_last_accepted[push_ctx_idx] <= block_last_in;
                end else if (block_last_in) begin
                    ctx_last_accepted[push_ctx_idx] <= 1'b1;
                end
            end

            // Queue metadata update, including simultaneous enqueue/dequeue of
            // the same context.
            if (multi_push && !ctx_pop) begin
                if (!ctx_pending_valid[push_ctx_idx]) begin
                    ctx_head[push_ctx_idx] <= pool_alloc_slot;
                    ctx_tail[push_ctx_idx] <= pool_alloc_slot;
                    ctx_pending_valid[push_ctx_idx] <= 1'b1;
                end else begin
                    ctx_tail[push_ctx_idx] <= pool_alloc_slot;
                end
            end else if (!multi_push && ctx_pop) begin
                if (pop_single_old) begin
                    ctx_pending_valid[pop_ctx_idx] <= 1'b0;
                end else begin
                    ctx_head[pop_ctx_idx] <= pool_link_rd_next;
                end
            end else if (multi_push && ctx_pop) begin
                if (push_ctx_idx == pop_ctx_idx) begin
                    if (pop_single_old) begin
                        ctx_head[pop_ctx_idx] <= pool_alloc_slot;
                        ctx_tail[pop_ctx_idx] <= pool_alloc_slot;
                        ctx_pending_valid[pop_ctx_idx] <= 1'b1;
                    end else begin
                        ctx_head[pop_ctx_idx] <= pool_link_rd_next;
                        ctx_tail[pop_ctx_idx] <= pool_alloc_slot;
                        ctx_pending_valid[pop_ctx_idx] <= 1'b1;
                    end
                end else begin
                    // Push context.
                    if (!ctx_pending_valid[push_ctx_idx]) begin
                        ctx_head[push_ctx_idx] <= pool_alloc_slot;
                        ctx_tail[push_ctx_idx] <= pool_alloc_slot;
                        ctx_pending_valid[push_ctx_idx] <= 1'b1;
                    end else begin
                        ctx_tail[push_ctx_idx] <= pool_alloc_slot;
                    end
                    // Pop context.
                    if (pop_single_old)
                        ctx_pending_valid[pop_ctx_idx] <= 1'b0;
                    else
                        ctx_head[pop_ctx_idx] <= pool_link_rd_next;
                end
            end

            if (launch_fire) begin
                launch_valid <= 1'b0;
                core_reserved[launch_core_id] <= 1'b0;
            end

            if (sched_fire) begin
                launch_valid       <= 1'b1;
                launch_is_fast     <= sched_use_fast;
                launch_core_id     <= sched_core_sel;
                launch_hash_bypass <= 1'b0;
                core_reserved[sched_core_sel] <= 1'b1;
                core_quantum[sched_core_sel] <= sched_use_fast ? '0 : QUANTUM_W'(1);

                if (sched_use_fast) begin
                    launch_ctx_id     <= fast_ctx_mem[fast_rd_ptr];
                    launch_msg_id     <= fast_msg_mem[fast_rd_ptr];
                    launch_fast_block <= fast_block_mem[fast_rd_ptr];
                    if (fast_rd_ptr == FAST_PTR_W'(FAST_DEPTH-1))
                        fast_rd_ptr <= '0;
                    else
                        fast_rd_ptr <= fast_rd_ptr + 1'b1;
                end else begin
                    launch_ctx_id <= sched_ctx_sel;
                    launch_msg_id <= '0;
                    ctx_inflight[sched_ctx_sel] <= 1'b1;
                    if (sched_ctx_sel == CTX_ID_W'(CTX_NUM-1))
                        ctx_rr_ptr <= '0;
                    else
                        ctx_rr_ptr <= sched_ctx_sel + 1'b1;
                end
            end

            if (sticky_issue) begin
                launch_valid       <= 1'b1;
                launch_is_fast     <= 1'b0;
                launch_ctx_id      <= commit_ctx_id;
                launch_msg_id      <= '0;
                launch_core_id     <= commit_core_sel;
                launch_hash_bypass <= 1'b1;
                launch_hash_value  <= commit_hash;
                core_reserved[commit_core_sel] <= 1'b1;
                core_quantum[commit_core_sel] <= core_quantum[commit_core_sel] + 1'b1;
            end

            if (fast_push)
                fast_pressure_count <= PRESSURE_W'(FAST_PRESSURE_HOLD);
            else if (fast_pressure_count != 0)
                fast_pressure_count <= fast_pressure_count - 1'b1;

            case ({fast_push, fast_pop})
                2'b10: fast_count <= fast_count + 1'b1;
                2'b01: fast_count <= fast_count - 1'b1;
                default: fast_count <= fast_count;
            endcase

            if (sched_fire) begin
                if (sched_use_fast) begin
                    if (sched_ctx_found) begin
                        if (fast_burst_count < FAST_BURST_W'(FAST_QUOTA))
                            fast_burst_count <= fast_burst_count + 1'b1;
                    end else begin
                        fast_burst_count <= '0;
                    end
                end else begin
                    fast_burst_count <= '0;
                end
            end

            if (commit_fire) begin
                if (commit_is_fast) begin
                    result_valid <= 1'b1;
                    digest_out   <= commit_hash;
                    msg_id_out   <= commit_msg_id;
                    ctx_id_out   <= commit_ctx_id;
                    result_fast  <= 1'b1;
                    core_quantum[commit_core_sel] <= '0;
                end else if (!commit_ctx_in_range) begin
`ifndef SYNTHESIS
                    $error("SM3 commit returned invalid context id %0d", commit_ctx_id);
`endif
                end else if (!ctx_valid[commit_ctx_id] || !ctx_inflight[commit_ctx_id]) begin
`ifndef SYNTHESIS
                    $error("SM3 commit on inactive/non-inflight context %0d", commit_ctx_id);
`endif
                end else if (commit_last) begin
`ifndef SYNTHESIS
                    if (ctx_pending_valid[commit_ctx_id])
                        $error("SM3 final commit while context %0d still has queued blocks", commit_ctx_id);
`endif
                    result_valid <= 1'b1;
                    digest_out   <= commit_hash;
                    msg_id_out   <= ctx_msg_id[commit_ctx_id];
                    ctx_id_out   <= commit_ctx_id;
                    result_fast  <= 1'b0;
                    ctx_valid[commit_ctx_id]         <= 1'b0;
                    ctx_pending_valid[commit_ctx_id] <= 1'b0;
                    ctx_inflight[commit_ctx_id]      <= 1'b0;
                    ctx_last_accepted[commit_ctx_id] <= 1'b0;
                    core_quantum[commit_core_sel] <= '0;
                end else if (!sticky_issue) begin
                    ctx_inflight[commit_ctx_id] <= 1'b0;
                    core_quantum[commit_core_sel] <= '0;
                end
            end
        end
    end

    sm3_block_pool #(
        .POOL_DEPTH(POOL_DEPTH)
    ) u_block_pool (
        .clk          (clk),
        .rst_n        (rst_n),
        .init_done    (pool_init_done),
        .free_count   (pool_free_count),
        .alloc_valid  (pool_alloc_valid),
        .alloc_ready  (pool_alloc_ready),
        .alloc_slot   (pool_alloc_slot),
        .alloc_block  (block_data),
        .alloc_first  (block_first_in),
        .alloc_last   (block_last_in),
        .free_valid   (pool_free_valid),
        .free_slot    (pool_free_slot),
        .link_wr_en   (pool_link_wr_en),
        .link_wr_slot (pool_link_wr_slot),
        .link_wr_next (pool_link_wr_next),
        .link_rd_slot (pool_link_rd_slot),
        .link_rd_next (pool_link_rd_next),
        .rd_en        (pool_rd_en),
        .rd_slot      (pool_rd_slot),
        .rd_block     (pool_rd_block),
        .rd_first     (pool_rd_first),
        .rd_last      (pool_rd_last)
    );

    genvar g;
    generate
        for (g = 0; g < CORE_NUM; g = g + 1) begin : g_core
            sm3_core #(.MSG_ID_W(TAG_W)) u_core (
                .clk            (clk),
                .rst_n          (rst_n),
                .in_valid       (core_in_valid[g]),
                .in_ready       (core_in_ready[g]),
                .block_data     (core_launch_block),
                .hash_in        (core_launch_hash),
                .msg_id_in      (core_launch_tag),
                .block_last_in  (core_launch_last),
                .out_valid      (core_out_valid[g]),
                .out_ready      (core_out_ready[g]),
                .hash_out       (core_hash_out[g]),
                .msg_id_out     (core_tag_out[g]),
                .block_last_out (core_last_out[g])
            );
        end
    endgenerate

endmodule
